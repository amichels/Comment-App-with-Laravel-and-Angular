# Be sure to restart your server when you modify this file.

Cellar::Application.config.session_store :cookie_store, key: '_cellar_session'
