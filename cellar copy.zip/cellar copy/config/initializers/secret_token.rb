# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Cellar::Application.config.secret_key_base = '06553b410af977b67a7c773e5a89226c7e86d0f5c08f772d22a1ebfc5ccb7d93bc1d6e3df0b6c2cf32a14e48e7c2dea4f4abde15cd7be66a026431e029d58898'
