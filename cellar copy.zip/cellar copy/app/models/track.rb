class Track < ActiveRecord::Base
	belongs_to :user
	has_many :lessons, dependent: :destroy

  	validates :user_id, presence: true
  	validates :name, presence: true
  	validates :description, length: { maximum: 144 }, presence: true
end
