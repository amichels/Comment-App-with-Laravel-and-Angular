class Lesson < ActiveRecord::Base
	belongs_to :track

  	validates :track_id, presence: true
  	validates :name, presence: true
  	validates :url, format: {with: Regexp.new(URI::regexp(%w(http https)))}, presence: true
end
