class SiteController < ApplicationController
  def index
  	@tracks = Track.order('created_at desc')
  end
end
