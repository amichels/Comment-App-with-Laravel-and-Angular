class LessonsController < ApplicationController
  before_action :authenticate_user!

  def new
    @track = Track.find(params[:track_id])
    @lesson = @track.lessons.build
  end

  def create
    @track = Track.find(params[:track_id])
    @lesson = @track.lessons.build(lesson_params)
    if @lesson.save
      flash[:notice] = "lesson has been created."
      redirect_to [@track]
    else
      flash[:alert] = "lesson has not been created."
      render "new"
    end
  end

  def edit
    @track = Track.find(params[:track_id])
    @lesson = @track.lessons.find(params[:id])
  end
  
  def update
    @track = Track.find(params[:track_id])
    @lesson = @track.lessons.find(params[:id])
    if @lesson.update_attributes(lesson_params)
      flash[:notice] = "Successfully updated lesson."
      redirect_to track_url(@lesson.track_id)
    else
      render :action => 'edit'
    end
  end

  def destroy
    @track = Track.find(params[:track_id])
    @lesson = @track.lessons.find(params[:id])
    @lesson.destroy
    flash[:notice] = "Successfully deleted."
    redirect_to track_url(@lesson.track_id)
  end

  private

    def lesson_params
      params.require(:lesson).permit(:name, :url)
    end

end