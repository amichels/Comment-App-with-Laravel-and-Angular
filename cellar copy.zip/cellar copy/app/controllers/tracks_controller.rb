class TracksController < ApplicationController
  before_action :set_track, only: [:show, :edit, :update, :destroy]
  #before_action :authenticate_user!

  def index
    @tracks = current_user.tracks.all
  end

  def show
    @track = Track.find(params[:track_id]) if params[:track_id].present?
    @lessons = @track.present? ? @track.lessons : Lesson.all
  end

  def new
    @track = current_user.tracks.new
  end

  def edit
  end

  def create
    @track = current_user.tracks.new(track_params)

    respond_to do |format|
      if @track.save
        format.html { redirect_to @track, notice: 'Track was successfully created.' }
      else
        format.html { render action: 'new' }
      end
    end
  end

  def update
    respond_to do |format|
      if @track.update(track_params)
        format.html { redirect_to @track, notice: 'Track was successfully updated.' }
      else
        format.html { render action: 'edit' }
      end
    end
  end

  def destroy
    @track.destroy
    respond_to do |format|
      format.html { redirect_to tracks_url }
    end
  end

  private
    def set_track
      unless @track = current_user.tracks.where(id: params[:id]).first
        flash[:alert] = 'Track not found.'
        redirect_to root_url
      end
    end

    def track_params
      params.require(:track).permit(:name, :description)
    end
end
